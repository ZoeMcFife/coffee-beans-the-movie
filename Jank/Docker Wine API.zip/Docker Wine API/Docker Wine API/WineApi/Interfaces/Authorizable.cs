﻿namespace WineApi.Interfaces
{
    public interface Authorizable
    {
        
    }
}
