﻿namespace WineApi.Model
{
    public class AdditiveType
    {
        public Guid Id { get; set; }
        public string Type { get; set; }
    }
}
