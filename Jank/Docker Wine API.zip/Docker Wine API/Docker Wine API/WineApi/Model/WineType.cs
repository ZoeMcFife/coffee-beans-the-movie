﻿namespace WineApi.Model
{
    public class WineType
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
    }
}
